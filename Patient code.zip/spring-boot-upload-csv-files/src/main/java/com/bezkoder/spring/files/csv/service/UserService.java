package com.bezkoder.spring.files.csv.service;

import java.util.List;

import com.bezkoder.spring.files.csv.exception.UserException;
import com.bezkoder.spring.files.csv.model.User;

public interface UserService {
	
	public User addUser(User user)throws UserException;
	
	public  List<User> getAllUsers()throws UserException;
	
	public boolean validateUserLogin(String username, String password)throws UserException;


}
