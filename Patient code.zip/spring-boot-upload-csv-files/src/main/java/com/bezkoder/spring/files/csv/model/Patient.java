package com.bezkoder.spring.files.csv.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//import org.hibernate.annotations.BatchSize;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "patients")
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int patientId;
	@Column(name = "patient_name", nullable = false)
	private String patientName;
	@Column(name = "patientAddress", nullable = false)
	private String patientAddress;
	@Column(name = "patientDateofBirth", nullable = false)
	private String patientDateofBirth;
	@Column(name = "patientEmail", nullable = false)
	private String patientEmail;
//	@BatchSize(size = 10)
	// @Digits(message="Number should contain 10 digits.", fraction = 0, Long = 10)
	// @NotBlank(message = "mobileNumber is required")
	@Column(name = "patientContactNumber", nullable = false)
	private Long patientContactNumber;
	@Column(name = "patientDrugId", nullable = false)
	private Long patientDrugId;
	@Column(name = "patientDrugName", nullable = false)
	private String patientDrugName;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "patientDateOfBirth", nullable = false)
	private String patientDateOfBirth;

	public Patient(int patientId, String patientName, String patientAddress, String patientDateofBirth,
			String patientEmail, Long patientContactNumber, Long patientDrugId, String patientDrugName,
			String patientDateOfBirth2) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.patientAddress = patientAddress;
		this.patientDateofBirth = patientDateofBirth;
		this.patientEmail = patientEmail;
		this.patientContactNumber = patientContactNumber;
		this.patientDrugId = patientDrugId;
		this.patientDrugName = patientDrugName;
		patientDateOfBirth = patientDateOfBirth2;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientAddress() {
		return patientAddress;
	}

	public void setPatientAddress(String patientAddress) {
		this.patientAddress = patientAddress;
	}

	public String getPatientEmail() {
		return patientEmail;
	}

	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}

	public Long getPatientContactNumber() {
		return patientContactNumber;
	}

	public void setPatientContactNumber(Long patientContactNumber) {
		this.patientContactNumber = patientContactNumber;
	}

	public Long getPatientDrugId() {
		return patientDrugId;
	}

	public void setPatientDrugId(Long patientDrugId) {
		this.patientDrugId = patientDrugId;
	}

	public String getPatientDrugName() {
		return patientDrugName;
	}

	public void setPatientDrugName(String patientDrugName) {
		this.patientDrugName = patientDrugName;
	}

	public String getPatientDateOfBirth() {
		return patientDateOfBirth;
	}

	public void setPatientDateOfBirth(String patientDateOfBirth) {
		this.patientDateOfBirth = patientDateOfBirth;
	}

//	@Override
//	public String toString() {
//		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", patientAddress=" + patientAddress
//				+ ", patientEmail=" + patientEmail + ", patientContactNumber=" + patientContactNumber
//				+ ", patientDrugId=" + patientDrugId + ", patientDrugName=" + patientDrugName + ", patientDateOfBirth="
//				+ patientDateOfBirth + "]";
//	}

}
