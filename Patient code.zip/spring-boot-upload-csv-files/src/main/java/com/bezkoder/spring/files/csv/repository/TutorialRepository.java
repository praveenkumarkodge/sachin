package com.bezkoder.spring.files.csv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bezkoder.spring.files.csv.model.Patient;

public interface TutorialRepository extends JpaRepository<Patient, Long> {
}
